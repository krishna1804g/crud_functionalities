import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import EventLandingPage from './demos/EventLandingPage';
import BlogIndex from './pages/BlogIndex';
import Signup from 'pages/Signup';
import Login from 'pages/Login';
import GlobalStyles from "styles/GlobalStyles";
import AboutUs from 'pages/AboutUs';


const App = () => {
  return (
    // <Router>
    //   <Routes>
    //     <Route exact path="/" component={EventLandingPage} />
    //     <Route path="/blog" component={BlogIndex} />
    //   </Routes>
    // </Router>
    <>
       <GlobalStyles />
       <Router>
         <Routes>
           {/* <Route path="/components/:type/:subtype/:name" element={<ComponentRenderer />} />*/}
           <Route path="/login" element={<Login/>} /> 
           <Route path="/signup" element={<Signup />} /> 
           <Route path="/blog" element={<BlogIndex />} />
           <Route path="/ngo" element={<AboutUs />} />
           <Route path="/" element={<EventLandingPage />} />

         </Routes>
       </Router>
     </>
  );
};

//   return (
//     <>
//       <GlobalStyles />
//       <Router>
//         <Routes>
//           <Route path="/components/:type/:subtype/:name" element={<ComponentRenderer />} />
//           <Route path="/components/:type/:name" element={<ComponentRenderer />} />
//           <Route path="/thank-you" element={<ThankYouPage />} />
//           <Route path="/" element={<MainLandingPage />} />
//         </Routes>
//       </Router>
//     </>
//   );

export default App;
