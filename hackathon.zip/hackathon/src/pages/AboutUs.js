import React from "react";
import tw from "twin.macro"; //eslint-disable-line
import AnimationRevealPage from "helpers/AnimationRevealPage.js";
import SucessStories from "components/ngo/ThreeColSimpleWithImageAndDashedBorder.js";
import Testimonial from "components/testimonials/TwoColumnWithImageAndProfilePictureReview.js";
import FAQ from "components/faqs/SimpleWithSideImage.js";
import ContactUsForm from "components/forms/TwoColContactUsWithIllustration.js";
import MainFeature1 from "components/features/TwoColWithButton.js";
import customerSupportIllustrationSrc from "images/customer-support-illustration.svg";
import Header from "components/headers/light.js";
import Footer from "components/footers/FiveColumnWithInputForm.js";


const Subheading = tw.span`uppercase tracking-wider text-sm`;        
export default () => (
  <AnimationRevealPage>
      <Header />
      <MainFeature1
        subheading={<Subheading>About GWC</Subheading>}
        heading="Contributions and Encourage Collaboration"
        buttonRounded={false}
        description="Discover the impactful journey of our dedicated NGOs, driving positive change through projects, partnerships, and community engagement for a brighter, more connected future."
        primaryButtonText="Collaborate with us"
        imageSrc="https://images.unsplash.com/photo-1617450365226-9bf28c04e130?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80"
      />

    
    <SucessStories />
    <FAQ
      imageSrc={customerSupportIllustrationSrc}
      imageContain={true}
      imageShadow={false}
      subheading="FAQs"
      heading={
        <>
          Projects &<span tw="text-primary-500"> Initiatives</span>
        </>
      }
    />
    <Testimonial
      subheading="NGO"
      heading={
        <>
          Our Clients <span tw="text-primary-500">Love Us.</span>
        </>
      }
      description="Discover the impactful journey of our dedicated NGOs, driving positive change through projects, partnerships, and community engagement for a brighter, more connected future."
      textOnLeft={true}
    />
    
    <ContactUsForm />
    <Footer />
  </AnimationRevealPage>
);